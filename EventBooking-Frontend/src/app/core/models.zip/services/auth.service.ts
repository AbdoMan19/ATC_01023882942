import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { User, UserRole } from '../models/user.interface';

interface AuthResponse {
  user: User;
  token: string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private apiUrl = `${environment.apiUrl}/auth`;
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  private redirectUrl: string | null = null;
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(
    private http: HttpClient,
    private router: Router
  ) {
    // Check for stored token and user data
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      this.currentUserSubject.next(JSON.parse(userData));
    }
  }

  get currentUser(): User | null {
    return this.currentUserSubject.value;
  }

  setRedirectUrl(url: string): void {
    this.redirectUrl = url;
  }

  getRedirectUrl(): string | null {
    const url = this.redirectUrl;
    this.redirectUrl = null;
    return url;
  }

  login(email: string, password: string): Observable<User> {
    if (environment.mockApi) {
      // Mock successful login
      const mockUser: User = {
        id: '1',
        email,
        name: 'Test User',
        role: UserRole.USER,
        createdAt: new Date()
      };
      localStorage.setItem('token', 'mock-token');
      localStorage.setItem('user', JSON.stringify(mockUser));
      this.currentUserSubject.next(mockUser);
      return of(mockUser);
    }
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, { email, password })
      .pipe(
        tap(response => {
          localStorage.setItem('token', response.token);
          localStorage.setItem('user', JSON.stringify(response.user));
          this.currentUserSubject.next(response.user);
        }),
        map(response => response.user)
      );
  }

  register(email: string, password: string, name: string): Observable<User> {
    if (environment.mockApi) {
      // Mock successful registration
      const mockUser: User = {
        id: Date.now().toString(),
        email,
        name,
        role: UserRole.USER,
        createdAt: new Date()
      };
      localStorage.setItem('token', 'mock-token');
      localStorage.setItem('user', JSON.stringify(mockUser));
      this.currentUserSubject.next(mockUser);
      this.router.navigate(['/events']);
      return of(mockUser);
    }
    return this.http.post<AuthResponse>(`${this.apiUrl}/register`, { email, password, name })
      .pipe(
        tap(response => {
          localStorage.setItem('token', response.token);
          localStorage.setItem('user', JSON.stringify(response.user));
          this.currentUserSubject.next(response.user);
          this.router.navigate(['/events']);
        }),
        map(response => response.user)
      );
  }

  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    this.currentUserSubject.next(null);
    this.router.navigate(['/auth/login']);
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.role === UserRole.ADMIN;
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  refreshToken(): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/refresh-token`, {})
      .pipe(
        tap(user => {
          localStorage.setItem('user', JSON.stringify(user));
          this.currentUserSubject.next(user);
        })
      );
  }

  // New methods for profile and settings components
  updateCurrentUser(updatedUser: User): Observable<User> {
    if (environment.mockApi) {
      // Mock successful update
      localStorage.setItem('user', JSON.stringify(updatedUser));
      this.currentUserSubject.next(updatedUser);
      return of(updatedUser);
    }
    
    return this.http.put<User>(`${this.apiUrl}/users/${updatedUser.id}`, updatedUser)
      .pipe(
        tap(user => {
          localStorage.setItem('user', JSON.stringify(user));
          this.currentUserSubject.next(user);
        })
      );
  }

  changePassword(currentPassword: string, newPassword: string): Observable<any> {
    if (environment.mockApi) {
      // Mock successful password change
      // In a real app, we would verify the current password first
      return of({ success: true });
    }
    
    return this.http.post<any>(`${this.apiUrl}/change-password`, {
      currentPassword,
      newPassword
    });
  }
} 