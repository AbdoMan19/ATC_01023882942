export interface Booking {
  id: string;
  eventId: string;
  eventName: string;
  eventDate: Date;
  eventTime: string;
  eventLocation: string;
  numberOfTickets: number;
  totalAmount: number;
  status: 'CONFIRMED' | 'PENDING' | 'CANCELLED';
  userId: string;
  createdAt: Date;
}

import { Event } from './event.model'; 