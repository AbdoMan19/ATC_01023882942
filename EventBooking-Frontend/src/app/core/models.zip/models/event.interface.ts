import { EventCategory } from './event-category.enum';

export interface Event {
  id: string;
  name: string;
  description: string;
  category: EventCategory;
  date: Date;
  venue: string;
  price: number;
  imageUrl: string;
} 