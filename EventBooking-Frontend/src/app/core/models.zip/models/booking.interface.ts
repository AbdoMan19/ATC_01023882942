import { BookingStatus } from './booking-status.enum';

export interface Booking {
  id: string;
  eventId: string;
  userId: string;
  bookingDate: Date;
  status: BookingStatus;
} 